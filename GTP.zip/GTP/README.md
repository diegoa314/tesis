Bit Error Ratio Analyzer - GSoC 2018 - Harsh Gugale

For features and implementation details please go to : https://gsoc2018blog.blogspot.com/2018/08/gsoc-2018-final-report.html
